from django.shortcuts import render, get_object_or_404, redirect

from django.urls import reverse

from .models import Movie
from .forms import CreateMovie, UpdateMovie


def all_movies(request):
    all_movies = Movie.objects.all()

    return render(request, 'movies/all_movies.html', {'movies':all_movies})


def create_movie(request):
    form = CreateMovie()

    if request.method == 'POST':
        form = CreateMovie(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('movie_collection_app:all_movies')
    
    context = {

        "form": form
    }
    return render(request, 'movies/create_movie.html', context)


def movie_detail(request, movie_id):
    movie = get_object_or_404(Movie, pk=movie_id)

    return render(request, 'movies/movie_detail.html', {'movie':movie})


def update_movie(request, movie_pk):
    movie = get_object_or_404(Movie, pk=movie_pk)
    update_movie = UpdateMovie(instance=movie)

    if request.method == 'POST':
        update_movie = UpdateMovie(request.POST, request.FILES, instance=movie)
        if update_movie.is_valid():
            update_movie.save()
            return redirect(reverse('movie_collection_app:movie_detail',kwargs={'movie_id': movie.id}))
    
    context = {

        "movie": movie,
        "form": update_movie
    }

    return render(request, 'movies/update_movies.html', context)


def confirm_delete(request, movie_id):
    movie = get_object_or_404(Movie, pk=movie_id)

    return render(request, 'movies/confirm_delete.html', {'movie':movie})

def delete_movie(request, movie_id):
    movie = get_object_or_404(Movie, pk=movie_id)

    if request.method == 'POST':
        movie.delete()
        return redirect('movie_collection_app:all_movies')