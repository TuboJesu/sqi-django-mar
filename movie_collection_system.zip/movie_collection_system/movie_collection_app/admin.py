from django.contrib import admin

from .models import Movie, GenreChoices

admin.site.register(Movie)

# Register your models here.
