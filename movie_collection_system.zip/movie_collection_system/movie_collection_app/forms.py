from django import forms

from .models import Movie

class CreateMovie(forms.ModelForm):
    class Meta:
        model = Movie
        fields = ['title', 'director', 'release_date', 'description', 'poster', 'genre']



class UpdateMovie(forms.ModelForm):
    class Meta:
        model = Movie
        fields = ['title', 'director', 'release_date', 'description', 'poster', 'genre']
