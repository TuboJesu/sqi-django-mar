from django.apps import AppConfig


class MovieCollectionAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'movie_collection_app'
