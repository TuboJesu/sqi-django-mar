document.addEventListener('DOMContentLoaded', () => {
    // Animate header on page load
    const header = document.querySelector('header');
    header.style.opacity = '0';
    header.style.transform = 'translateY(-20px)';
    
    setTimeout(() => {
        header.style.transition = 'all 0.5s ease';
        header.style.opacity = '1';
        header.style.transform = 'translateY(0)';
    }, 100);

    // Add hover effect to footer
    const footer = document.querySelector('footer');
    footer.addEventListener('mouseenter', () => {
        footer.style.transform = 'scale(1.02)';
    });

    footer.addEventListener('mouseleave', () => {
        footer.style.transform = 'scale(1)';
    });
});